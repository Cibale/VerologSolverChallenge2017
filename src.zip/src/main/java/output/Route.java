package main.java.output;

import java.util.LinkedList;
import java.util.List;

/**
 * Created by mmatak on 6/15/17.
 */
public class Route {
    public int vehicleId;
    //each route must start and end with depotId, i.e. 0
    public List<Integer> doneRequests = new LinkedList<>();
}

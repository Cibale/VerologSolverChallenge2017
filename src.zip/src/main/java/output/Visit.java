package main.java.output;

/**
 * Tells us more information about vehicle which visits depot.
 * Created by mmatak on 6/15/17.
 */
public class Visit {
    public int dayId;
    public int vehicleId;
    //which time is this that vehicle is by depot
    public int visitNumber;
    public int[] tools;
}
